In the given code I have included the file ticket.py it has all the 
python code in the file and it can be directly using the pycharm or any IDE
supporting the python the code 
Code has the ticket class having all the information related to ticket 
then we have the methods with parameter in order to get the ticket details 